# 1.0.2

Removed the No Heal mod from this, oops

# 1.0.1

Updated icon

# 1.0.0

Initial Release
