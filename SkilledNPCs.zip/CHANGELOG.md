# 1.0.1

Added "PlayAllCards" Mode for extra funsies.

Changed Icon.

# 1.0.0

Initial Release
